Software Details:

Python 3

Packages:

*Opencv
*Pytesseract

Terminal commands for run:

python filename.py