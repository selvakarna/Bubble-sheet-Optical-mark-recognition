### IMAGE TO TEXT ####
####Type 1##########
import cv2
import numpy as np
import pytesseract
import os
import datetime
img=cv2.imread(r'Image_root\img.jpg')
gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
cv2.namedWindow("image",cv2.WINDOW_GUI_NORMAL)
cv2.imshow("image",threshold)
cv2.waitKey(0)
## Threshold process
# threshold=182

retval, threshold = cv2.threshold(gray, 111, 222, cv2.THRESH_BINARY)
# thres_img=gray-threshold

strl_ele = cv2.getStructuringElement(cv2.MORPH_RECT, (18, 18)) 
dial_img = cv2.dilate(threshold, strl_ele, iterations = 3) 
contors, hier = cv2.findContours(dial_img, cv2.RETR_EXTERNAL,  
                                                 cv2.CHAIN_APPROX_NONE) 
####
for cont in contors: 
    x, y, w, h = cv2.boundingRect(cont) 
    rect = cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2) 
    Segmented_image = img[y:y + h, x:x + w] 


################OCR Process####################
#########IMAGE TO TEXT#########################

def textwrite(text):
    
    current_dir=os.getcwd()
    print('root is',current_dir)
    txt_file = os.path.join(current_dir,"output_text.txt")
    file2 = open(txt_file, "a")
    var=str(text)
    file2.write(str(var)+'\n')
    file2.close()

text = pytesseract.image_to_string(Segmented_image) 
textwrite(text)
            
## Type 2 code
## TEXT EXTRACTION PART


from PIL import Image
import pytesseract
data_path = os.path.join(cwd, '*jpg')
files = glob.glob(data_path)


for f1 in sorted(files):
   

    im = Image.open(f1)
    print(f1)

    text = pytesseract.image_to_string(im, lang = 'eng')
    textwrite(str(text))
    print('Text is ',text)
























