clc
clear aall;
close all;
%%%%%%%%%%%%%%%%%%%
input_image=imread('image root/.jpg');
%%%%%%%%%%%%
% Select roi area for crop
crop_img=imcrop(input_image);

text_output=ocr(crop_img);  