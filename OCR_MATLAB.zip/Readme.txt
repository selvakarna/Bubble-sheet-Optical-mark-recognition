Software Details:

MATLAB 2014a 

Package:
  * OCR
  * Image Processing
